<html>
	<head>
		<title>ABGESENDET</title>
	</head>
<body>
	<?php	
	
		if(isset($_POST["abschicken"])):
		$firstname = $_POST["vorname"];
		$surname = $_POST["nachname"];
		$email = $_POST["email"];
		$company = $_POST["firma"];
		endif;
		
		if (!empty($firstname) || !empty($surname) || !empty($email) || !empty($company))  {
		
	    $db = mysqli_connect("Host", "Nutzername", "Passwort", "Datenbank");
	    if(!$db)
	    {
	        exit("Verbindungsfehler: ".mysqli_connect_error());
	    } else {
	        $INSERT = "INSERT Into Datenbankname ("vorname", "nachname", "email", "firma") values (?,?,?,?)";
	        
             $stmt = $db->prepare($INSERT);
             $stmt->bind_param("ssss", $vorname, $nachname, $email, $firma);
	         $stmt->execute();
	         echo "Anmeldung erfolgreich.";
	    }
	    
	    $stmt->close();
	    $db->close();
		    
		} else {
		    echo "Bitte alle Felder ausf�llen.";
		    die();
		}
   ?>
	</body>
</html>
